import java.util.*;
/**
 * HeapD - a class that implements the D heap
 * @author Jacob Kilimnik
 *
 */
public class HeapD {
	private int dval = 3,size = 0;
	/**
	 * a method that takes a list(L) of numbers and creates a heap with d sons in the
	 * array S
	 * @param S - the array that holds in which the d heap is represented
	 * @param d - the amount of sons the heap has
	 * @param L - the list  of numbers to be heaped
	 */
	void buildHeap(int[] S,int d,ArrayList L){
		dval = d;
		Integer[] vector = (Integer[]) L.toArray(new Integer[0]);
		for (int i = 0; i < L.size(); i++) { 
			S[i] = vector[i];
			size++;
		}
		if (size >= 2){
			for (int i = ((size-2)/dval); i >= 0; i=i-1) {
				heapify(S,i);
			}
		}else{
			heapify(S,0);
		}
		

	}
	/**
	 * a method that takes an array that holds the heap S, and changed the amount of
	 * sons it has to a given int d
	 * @param S - the array that holds the heap
	 * @param d - the number of sons to change to
	 */
	void changeD(int[] S,int d){
		dval = d;
		if (size >= 2){
			for (int i = ((size-2)/(dval)); i >= 0; i=i-1) {
				heapify(S,i);
			}
		}else{
			heapify(S,0);
		}
		
	}
	/**
	 * a method that inserts a new element to the heap (limited to 500 insertions due to 
	 * the limitations of the int[] data structure .
	 * @param S - the array that holds the heap (notice it can't change its size dynamically
	 * @param x - the int to be inserted into the existing heap
	 */
	void insert(int[] S,int x){
		S[size]=x;
		rollup(S,size);
		size++;
	}
	/**
	 * the heapify method , compares the parent i to its largest son (found in O(d))
	 * and swaps them when needed then does the same recursively for the cell that 
	 * held the son after replacement.
	 * @param S - the array that holds the heap
	 * @param i - the index of the element to be heapified 
	 */
	void heapify(int[] S,int i){
		int largest = i;
		int biggestSon = getBiggestSonIndex(S, i);
		if (biggestSon < size && S[i] < S[biggestSon]) {
			largest = biggestSon;
		} else {
			largest = i;
		}
		if (largest != i){
			swap(S,i,largest);
			heapify(S,largest);
		}
	}
	/**
	 * swaps between 2 elements in the given indexes in array S
	 * @param S - the array that holds the heap
	 * @param i - an index of an element to be swapped
	 * @param j - an index of an element to be swapped
	 */
	void swap(int[] S,int i,int j){
		int temp = S[i];
		S[i] = S[j];
		S[j] = temp;
	}
	/**
	 * returns the index of i's parent
	 * @param i - the cell in question
	 * @return - the parent of the cell in question
	 */
	int getParentIndex(int i){
		return (i-1)/dval;
	}
	/**
	 * returns the index of a specific son 
	 * @param i - the parent
	 * @param sonNum - the index of the son wanted (range depends on d)
	 * @return - the son's value
	 */
	int getSonIndex(int i,int sonNum){
		return (i*dval)+sonNum;
	}
	/**
	 * returns the biggest son index from all of i sons
	 * @param S - the array that holds the heap
	 * @param i - the index of the parent of whom the sons are checked for the biggest one 
	 * to be found and returned 
	 * @return - the index of the biggest son , if no such son returns i
	 */
	int getBiggestSonIndex(int[] S,int i){
		int biggest = (i*dval)+1;
		if (allSonsExist(S,i)){
			for (int j = (i*dval)+1; j <= (i*dval)+dval; j++) {
				if (S[j] > S[biggest]){
					biggest = j;
				}
			}
		}
		else if(someSonsExist(S,i)){
			int numOfSons = howManySonsExist(S,i);
			for (int j = (i*dval)+1; j <= (i*dval)+numOfSons; j++) {
				if (S[j] > S[biggest]){
					biggest = j;
				}
			}
			
		}else{
			return i;
		}
		
		return biggest;
	}
	/**
	 * a boolean method that checks if the parent i has all of its sons or not
	 * @param S - the array that holds the heap
	 * @param i - the parent in question
	 * @return - true if parent has all its sons , false if not.
	 */
	boolean allSonsExist(int[] S,int i){
		return (((i*dval)+dval)<size);
	}
	/**
	 * a method that checks if parent has some of its sons or none
	 * @param S - the array that holds the heap
	 * @param i - the parent in question
	 * @return - true if some sons exist false if none exit
	 */
	boolean someSonsExist(int[] S,int i){
		return (((i*dval)+1)<size);
	}
	/**
	 * counts how many sons the parent has
	 * @param S - the array that holds the heap
	 * @param i - the parent in question 
	 * @return - number of sons
	 */
	int howManySonsExist(int[] S,int i){
		int counter = 0;
		for (int j = (i*dval)+1; j <= (i*dval)+dval; j++) {
			if (j < size){
				counter ++;
			}
			else{
				return counter;
			}
		}
		return counter;
	}
	/**
	 * prints out the heap in S
	 * @param S - the array that holds the heap
	 */
	void printHeap(int[] S){
		for (int i = 0; i < size; i++) {
			System.out.print(S[i]+",");
		}
		System.out.println("");
	}
	/**
	 * extracts the max by replacing the smallest value in the heap with it 
	 * reducing the size of the heap by one and rolls the new value in the 
	 * first cell (head) to its proper place by using heapify
	 * @param S
	 */
	void extractMax(int[] S){
		int num = S[size-1];
		S[size-1] = 0;
		S[0] = num;
		heapify(S,0);
		size--;
	}
	/**
	 * moving the value in cell i to its proper place by comparing it to its parent
	 * and so forth
	 * @param S - the array that holds the heap
	 * @param i - the cell in question
	 */
	void rollup(int[] S,int i){
		boolean notinplace = true; 
		while (i > 0 && notinplace){
			if (S[getParentIndex(i)] < S[i]){
				swap(S, i, getParentIndex(i));
				i = getParentIndex(i);
			}else{
				notinplace = false;
			}
		}
	}
}
