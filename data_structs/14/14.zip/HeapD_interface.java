import java.util.*;
/**
 * an interface for the HeapD class
 * @author Jacob Kilimnik
 * @Sar - this variable holds the array in which HeapD will make the heap
 */
public class HeapD_interface {
	int[] Sar;
	Scanner sc = new Scanner(System.in);
	HeapD heap = new HeapD();
	public ArrayList<Integer> listy = new ArrayList<Integer>();
	/**
	 * a method that runs an example execution
	 */
	public void example(){
		ArrayList<Integer> arr = new ArrayList<Integer>();
		arr.add(8);arr.add(3);arr.add(7);arr.add(2);arr.add(1);arr.add(4);arr.add(5);
		int[] h = new int[arr.size()];
		HeapD heap = new HeapD();
		heap.buildHeap(h, 2, arr);
		print("This is a 2 son heap we just made: ");
		heap.printHeap(h);
		heap.changeD(h,3);
		print("Now we have changed it to a 3 son heap: ");
		heap.printHeap(h);
		heap.extractMax(h);
		print("Removed the max: ");
		heap.printHeap(h);
		heap.insert(h, 8);
		print("Inserted 8: ");
		heap.printHeap(h);
	}
	/**
	 * an assistive private method.
	 * @param str
	 */
	private void print(String str){
		System.out.print(str);
	}
	/**
	 * a method that runs the request for the list , gets the list
	 * and asks the HeapD object to create a heap
	 */
	public void getListandMakeHeap(){
		System.out.print("please type in the list of numbers you want heaped seperated " +
				"by spaces and when you" +
				" are done write end and hit enter");
	      while (sc.hasNextInt()) {
	          listy.add(sc.nextInt());
	      }	   
	    System.out.println("please choose the amount of sons each parent in the heap will have");
	    sc.next();
	    int d = sc.nextInt();
	    int[] S = new int[listy.size()+500]; // made extra 500 hundred places for inserted values, 
	    heap.buildHeap(S, d, listy);		// arrays can't be changed dynamically so you left me
	    Sar = S;							// no choice but to do this ....
	}
	/**
	 * this is the method that calls insert and enters the users input 
	 */
	public void insertion(){
		if (Sar == null){
			System.out.println("If you dont create a heap you cant insert anything into it..");
		}else{
			System.out.println("please choose what number you want to insert into the heap");
			int x = sc.nextInt();
			heap.insert(Sar, x);
		}
	}
	/**
	 * this method calls HeapD's extractMax
	 */
	public void extract_max(){
		if (Sar == null){
			System.out.println("Can't extract max from a none existant heap...");
		}else{
			System.out.println("extracting the biggest number from the heap...");
			heap.extractMax(Sar);
		}
	}
	/**
	 * this method calls changeD
	 */
	public void chooseD(){
		if (Sar == null){
			System.out.println("Can't change amount of sons for a heap that does not " +
					"exist...");
		}else{
			System.out.println("please choose the new amount of sons you wish the heap to have");
			int d = sc.nextInt();
			heap.changeD(Sar, d);
		}
		
	}
	/**
	 * this method calls printHeap
	 */
	public void printHeap(){
		if (Sar == null){
			System.out.println("Sorry, but i cant print out a none existant heap...");
		}else{
			heap.printHeap(Sar);
		}
	}
	/**
	 * this is the method that calls this.menu() and takes user input 
	 * and acts according to his command.
	 */
	public void start(){
		boolean exit = false;
		while (!exit) {
			menu();
			int input = sc.nextInt();
			switch (input) {
			case 1:
				this.getListandMakeHeap();
				this.printHeap();
				break;
			case 2:
				this.chooseD();
				this.printHeap();
				break;
			case 3:
				this.insertion();
				this.printHeap();
				break;
			case 4:
				this.extract_max();
				this.printHeap();
				break;
			case 5:
				this.printHeap();
				break;
			case 6:
				this.example();
				break;
			case 7:
				exit = true;
				break;
			default:
				menu();
				break;
			}
		}
		sc.close();
	}
	/**
	 * here the menu is hosted 
	 */
	private void menu(){
		System.out.println("Please choose an action:\n" +
				"1. build a heap\n" +
				"2. change the amount of sons in the heap\n" +
				"3. insert a new integer into the heap\n" +
				"4. remove maximum from heap\n" +
				"5. print heap\n" +
				"6. example\n" +
				"7. exit\n");
	}
	/**
	 * here it all starts
	 * first we show an example then we start the start() method
	 * that starts the user input loop
	 * @param args
	 */
	public static void main(String[] args){	
	    HeapD_interface heapIface = new HeapD_interface();  
		heapIface.example();
		System.out.println("");
	    heapIface.start();
	}
}
