        function q_focused(element){ 
            if (element.value == "הקלד את שאלתך") {
                element.className = "question_focused";
                element.value="";
            }
        };
        function q_blurred(element){ 
            if (element.value == "") {
                element.className = "question";
                element.value = "הקלד את שאלתך";
            }
        };
       $(document).ready(function(){
        /* upload input specific js */
			$("input[type=file]").change(function(e){
				var inp = $(this);
				$(this).next().children().first().text(inp.attr('value'));
			});
        /* upload input specific js */
        /* initializing selected values in dropdown */
       		$(".js_selected_answer_disp").text($(".answer_type .selected").text());
       		$(".js_selected_poll_disp").text($(".poll_type .selected").text());
        /* initializing selected values in dropdown */
            $(".js_dropdown").click(function(){
                    $(this).next().fadeToggle();
             });
            $('.ddul li').click(function(elem){
                var dropping_div = $(this).parent().parent();
                dropping_div.fadeToggle();    
                var my_val = $(this).attr("rel");
                var my_txt = $(this).text();
                var answer_type_enum = {"yesno":"1","yesnomaybe":"2","rank":"3","scale":"4","custom":"0"}
                var poll_type_enum = {"ragil":"0","video":"5","photo":"4","audio":"6","text":"7"}
                /* animations */
                          var visible = $(".media_section > div").filter(":visible");
                          switch(my_val){
                          	case "video":
                          		if (!visible.is(".add_video")){
                          			visible.hide();
                          			$(".add_video").fadeIn();
                          		}
                          	break;
                          	case "audio":
                          	    if (!visible.is(".add_audio")){
                          			visible.hide();
                          			$(".add_audio").fadeIn();
                          		}
                          	break;
                          	case "text":
                          	 	if (!visible.is(".add_text")){
                          			visible.hide();
                          			$(".add_text").fadeIn();
                          	 	}
                          	break;
                          	case "photo":
                          	 	if (!visible.is(".add_photo")){
                          			visible.hide();
                          			$(".add_photo").fadeIn();
                          	 	}
                          	break;
                          	case "ragil":
                          		visible.hide();
                          		 $(".mboxes").show().fadeIn();
                            break;
                            default:
                            break;
                          }
                if (dropping_div.is(".answer_type")){
                    $("input#HFAnswerType").attr("value", answer_type_enum[my_val]);
                    $(".js_selected_answer_disp").text(my_txt);
                    if (my_val == "custom"){
                    	$(".custom").animate().fadeIn();
                    }else{
                    	$(".custom").animate().fadeOut();
                    }
                }
                if (dropping_div.is(".poll_type")){
                    $("input#HFPollType").attr("value", poll_type_enum[my_val]);
                    $(".js_selected_poll_disp").text(my_txt);
                }
                /*HFAnswerType HFPollType*/
            });
            /*
                .click( function() {
                console.log("lol"); 
                console.log($(this));
                $(this).nextSibling.nextSibling.animate({display:"block"},100);
            });*/
       });
