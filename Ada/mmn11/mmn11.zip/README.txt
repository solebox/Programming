i created the binaries on ubuntu-linux-64bit, thats why those arn't 
exe files you are looking at
